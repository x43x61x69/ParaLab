# ParaLab Link

給 **Tamagotchi Paradise** 使用的觸控道具工具與 USB–UART 橋接器。可直接在裝置上瀏覽與傳送道具、查詢 Lab Codes、發起 Playdate，或連接電腦使用支援 USB 串列埠的工具。

**版本 0.1.10** · [快速開始](#快速開始) · [功能](#功能) · [接線](#接線) · [建置與燒錄](#建置與燒錄) · [原始碼結構](#原始碼結構) · [來源與授權](#來源與授權)

## 快速開始

1. 使用 **LILYGO T-Display-S3 AMOLED 1.91 吋觸控版**，規格為 ESP32-S3R8、16 MiB Flash、8 MiB OPI PSRAM、536 × 240 AMOLED。
2. 首次安裝請燒錄 [完整映像檔](dist/paralab-link-0.1.10-factory.bin)。從 0.1.3 或更早版本升級時，請一併更新程式與素材包。
3. 重啟後，標題列會顯示版本。使用觸控操作，或透過 USB 連接電腦，選擇 **ParaLab Link** 串列埠。

## 功能

| 功能 | 用法 |
| --- | --- |
| **Gifts** | 選好禮物後，在 ParaLab Link 按 **Send Gift**，再到 Paradise 的 **Connect → Gift** 按 **B**。道具需由接收端 ROM 支援。 |
| **Lab Items · Coins** | 傳送 Lab Items 或 Money Boost。先在 Paradise 上開啟 **Connect → Download**。 |
| **Playdates** | 按世界挑選角色，包含 **Neon Planets** 的 86 個訪客。在 Paradise 開啟 Playdate 後，依兩邊畫面的提示操作。 |
| **Lab Codes** | 查看研究代碼，到 Paradise 的研究記錄畫面手動輸入。 |
| **USB Bridge · Link Test** | 查看 USB 和 UART 流量、重送最近擷取的資料段，或測試 UART 連線。 |
| **Favorites · Last Item** | 開啟收藏或最近一次成功傳送的道具。收藏保存在 NVS，最近一次傳送記錄會在重啟時清除。 |
| **Settings** | 調整亮度、旋轉螢幕與觸控方向、選擇物件名稱語言，或查看裝置資訊。 |

可翻頁畫面的標題列會顯示目前頁數。短按右側箭頭或滑動即可翻頁。按住上箭頭約 0.65 秒時，進度線會亮起並返回上一層，第一頁和單頁畫面也適用。物件清單每頁顯示四件。點選道具後可加入收藏，或按 **Continue** 查看對應的傳送步驟。確認畫面可按 **Cancel** 返回，傳輸中可按 **Stop**。實體 **BOOT** 短按返回、長按回首頁，傳輸中按下則要求停止。

**More** 一頁可開啟收藏、最近傳送的物件、設定、USB 橋接、連線測試與指南。接線說明位於指南第一頁。

連續 30 秒沒有操作或 USB／UART 資料收發時，螢幕會熄滅，背景橋接繼續運作。觸碰螢幕、按 **BOOT** 或有資料收發時會喚醒。喚醒用的第一次觸碰只會點亮畫面。

背景橋接會在本機操作取得 UART 後暫停，完成後恢復。請依序從電腦或觸控介面發起傳輸，讓 UART 有足夠時間完成前一筆交易。

### 物件名稱語言

物件名稱預設為 **English**。在 **More → Settings → Item names** 選擇語言，裝置會保存選擇並套用至清單、詳細資訊與傳送確認畫面。支援英文、法文、西班牙文、德文、葡萄牙文、義大利文、日文、簡體中文及韓文，另有繁體中文。此設定只改變顯示名稱。[Paradise 官方語言清單](https://tamagotchi-official.com/us/series/paradise/faq/)

## 接線

使用板上的 **UART** 四針插口。

| ParaLab Link | Tamagotchi Paradise |
| --- | --- |
| TX（GPIO43） | RX |
| RX（GPIO44） | TX |
| GND | GND |
| 3V3 | 留空 |

兩台裝置各自供電。GPIO43 可能在重啟時輸出 ESP32 的開機訊息，請先完成燒錄或重啟，再接 Paradise 訊號線。

## 建置與燒錄

在專案根目錄使用同一個 Python 環境安裝 PlatformIO 並打包。

```sh
python3 -m venv .venv
. .venv/bin/activate
python -m pip install platformio
pio run -d firmware
python tools/package_firmware.py
```

PlatformIO 使用 `espressif32@6.12.0`。成品與 SHA-256 紀錄位於 [dist](dist/)，版本來源為 [link_version.h](firmware/include/link_version.h)。

**進入燒錄模式**　螢幕朝向你、USB‑C 孔朝下時，按住左側 **BOOT**、按一下右側 **RESET**，再放開 **BOOT**。將 `LINK_PORT` 設為此時出現的串列埠。使用 esptool 4.9.0 執行下列指令。

```sh
python -m pip install 'esptool==4.9.0'
```

### 首次安裝

完整映像檔包含 bootloader、分割表、程式、素材與空白 LittleFS，會覆寫裝置上的韌體和儲存資料。

```sh
python -m esptool --chip esp32s3 --port "$LINK_PORT" --baud 460800 \
  --after watchdog_reset write_flash 0x0 dist/paralab-link-0.1.10-factory.bin
```

### 更新已安裝的裝置

已使用相同分割表且裝有相容素材包時，只寫入程式分割區即可保留收藏、設定和 LittleFS 資料。從 0.1.1 起，結束進行中的傳輸、關閉瀏覽器或串列終端的連線後，可以直接從一般 USB 模式更新。

```sh
python tools/flash_firmware.py
```

從更早的版本升級時，先用 **BOOT + RESET** 進入燒錄模式，再執行 `python tools/flash_firmware.py --boot-port "$LINK_PORT"`。

從 0.1.3 或更早版本更新時，請執行 `python tools/flash_firmware.py --with-assets`，一併安裝 Neon Planets 訪客素材。

## 原始碼結構

| 路徑 | 內容 |
| --- | --- |
| [firmware/src](firmware/src/) | 觸控介面、顯示驅動、UART 協定與 USB 橋接 |
| [firmware/include](firmware/include/) | 硬體腳位、產品名稱、版本和共用介面 |
| [firmware/generated](firmware/generated/) | 內建圖文目錄、字形表與配色 |
| [asset-pack](asset-pack/) | 素材映像檔與目錄資料 |
| [tools](tools/) | 韌體打包與字形產生工具 |
| [tests](tests/) | 按鍵、橋接仲裁與封包編解碼測試 |

<details>
<summary>重建字形表</summary>

```sh
python -m pip install -r tools/requirements.txt
python tools/build_catalog.py
python tools/build_item_names.py
python tools/build_fonts.py /path/to/fonts
```

字型目錄需有 `AtkinsonHyperlegible-Regular.ttf`、`AtkinsonHyperlegible-Bold.ttf`、`NotoSansCJKtc-Medium.otf` 和 `NotoEmoji-Regular.ttf`。若要重新匯入名稱，先執行 `node tools/import_item_names.cjs /path/to/ParaLab /path/to/rom-dumps`。一般建置可直接使用內附的名稱與字形表。

若要從自己的 Neon Planets ROM 重建訪客素材，先執行 `node tools/import_neon_visitors.cjs /path/to/ParaLab /path/to/neon-rom.bin`，再重新匯入名稱並執行上方三個產生指令。

</details>

## 來源與授權

| 內容 | 來源 |
| --- | --- |
| USB–UART 橋接基礎 | [TamaHome-ESP32-C3-UART-USB](https://github.com/FattLlama/TamaHome-ESP32-C3-UART-USB) |
| 道具目錄和素材 | [bbamorachi-tools](https://tools.bbamorachi.us/) 與 Paradise Neon Planets 的原生道具素材 |
| 多語名稱 | ParaLab 的禮物目錄、Lab Item ARC2 名稱與 Paradise ROM 文字表 |
| 英文與數字字型 | Atkinson Hyperlegible Regular／Bold，[OFL 授權](licenses/Atkinson-Hyperlegible-OFL.txt) |
| 中、日、韓字型 | Noto Sans CJK TC Medium，[OFL 授權](licenses/Noto-CJK-OFL.txt) |
| 日文道具名的表情符號 | Noto Emoji，[OFL 授權](licenses/Noto-Emoji-OFL.txt) |

韌體程式碼沿用 [GPL-3.0-or-later](LICENSE)。ParaLab Link 是非官方同好專案，第三方商標、角色與素材的權利屬於各自權利人。
